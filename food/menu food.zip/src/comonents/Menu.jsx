
import { useState } from "react"

import { menuFood } from "../hook/useMenu";


export const Menu = () => {
    const [menuList, setMenuList] = useState([])

   
        const newList = menuFood();
        const list = [...menuList, newList]
        setMenuList(list)
       
   
    return(
        <div>
           {
            menuList.map(({id,img,title,price})=>{
                <div key={id}>
                    <img  src={img}/>
                    <h1>{title}</h1>
                    <p>{price}</p>
                </div>
            })
           }
          
        </div>
    )
}