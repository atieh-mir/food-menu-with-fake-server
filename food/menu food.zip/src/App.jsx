import { Route, Routes } from "react-router-dom"
import { Home ,Header,Footer, Menu} from "./comonents"

function App() {

  return (
    <div>
      <Header />
      
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/menu" element={<Menu />} />
    </Routes>
    <Footer />
    </div>
  )
}

export default App
