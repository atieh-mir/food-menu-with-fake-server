import {Butter,Chole,Gujrati,Idli,Masala, Rajasthani} from "./useMenuImg"
export const useMenu =() => {

const menuFood = [
    
   {  id:1,
     title:"Butter Paneer",
    img: Butter,
    price:"$6"},
    {
        id:2,
    title:"Chole Bhature",
    img: Chole,
    price:"$8"
    }
    ,{
        id:3,
    title:"Gujrati Thali",
    img: Gujrati,
    price:"$5"
    }
    ,{
        id:4,
    title:"Idli vada",
    img: Idli,
    price:"$20"
    }
    ,{
        id:5,
    title:"Masala Dosa",
    img: Masala,
    price:"$30"
    }
    
    ,{
        id:6,
    title:"Rajasthani thali",
    img: Rajasthani,
    price:"$40"
    }
    
    
]




return(
    menuFood
)
}