import Butter from "../image/Butter .jpg";
import Chole from "../image/Chole .jpg";
import Gujrati from "../image/Gujrati.jpeg"
import Idli from "../image/Idli .jpg"
import Rajasthani from "../image/Rajasthani .jpg"
import Masala from "../image/Masala .jpg";

export{
    Butter,
    Chole,
    Gujrati,
    Idli,
    Rajasthani,
    Masala
}




